extends CharacterBody2D

var max_hp: int = 5
var current_hp: int = 3
const SPEED = 300.0
const JUMP_VELOCITY = -400.0

@onready var anim: AnimatedSprite2D = $AnimatedSprite2D

# Локальная переменная ui нам больше вообще не нужна, 
# так как мы общаемся с интерфейсом через GLOBAL.current_ui

func _ready() -> void:
	pass # Функция готова к работе, ошибок тут больше нет

func _physics_process(delta: float) -> void:
	# Гравитация
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Прыжок
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Движение влево/вправо
	var direction := Input.get_axis("ui_left", "ui_right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
		
	update_animation()
	move_and_slide()

func update_animation():
	if velocity.x < 0:
		anim.flip_h = true
	elif velocity.x > 0:
		anim.flip_h = false 
	
	if velocity.x:
		anim.play("Run")
	else:
		anim.play("Idle")
		
	if velocity.y < 0:
		anim.play("Run") # Если есть анимация прыжка, можно заменить "Run" на неё
	elif velocity.y > 0:
		anim.play("Fall")

func on_death():
	get_tree().change_scene_to_file.call_deferred("res://game_offer.tscn")
	self.queue_free()

func _on_pickup_area_area_entered(area: Area2D) -> void:
	if area.has_method("on_pickup"):
		area.on_pickup(self)

func hit() -> void:
	# 1. Отнимаем здоровье у САМОГО игрока
	current_hp -= 1
	print("ХП Игрока: ", current_hp)
	
	# 2. Передаем команду интерфейсу напрямую через Глобальный скрипт
	if GlobalVars.current_ui != null:
		GlobalVars.current_ui.hit() 
	else:
		print("Внимание: Интерфейс еще не зарегистрирован в GLOBAL.current_ui")
		
	# 3. Проверяем смерть игрока
	if current_hp <= 0:
		on_death()
func heal() -> void:
	# 1. Проверяем, не заполнено ли уже здоровье до максимума
	if current_hp >= max_hp:
		print("У игрока уже максимальное здоровье!")
		return # Если здоровье полное, прерываем функцию (аптечка не подберётся)
		
	# 2. Прибавляем здоровье САМОМУ игроку
	current_hp += 1
	print("Игрок исцелен! Текущее ХП: ", current_hp)
	
	# 3. Передаем команду интерфейсу обновиться через Глобалку
	if GlobalVars.current_ui != null:
		GlobalVars.current_ui.heal()
	else:
		print("Внимание: Интерфейс еще не зарегистрирован в GLOBAL.current_ui")
