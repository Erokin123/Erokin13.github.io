extends CanvasLayer

@export var heart_scene : PackedScene
var max_hp: int = 5 
var current_hp: int = 3

func _ready() -> void:
	GlobalVars.current_ui = self
	setup_hp()

func heal() -> void:
	current_hp += 1
	validate_hp()
	setup_hp() # Обновляем сердечки на экране

func hit() -> void:
	current_hp -= 1
	validate_hp() # Проверяем, чтобы ХП не ушло в минус или плюс
	setup_hp()    # ИСПРАВЛЕНО: Теперь перерисовываем сердечки!

func setup_hp() -> void:
	clean_current_representation()
	draw_hearts()

func clean_current_representation() -> void:
	for child in $HBoxContainer.get_children():
		child.queue_free()

func draw_hearts() -> void:
	# Чтобы не было ошибок, рисуем сердечки только если они > 0
	if current_hp > 0:
		for x in current_hp:
			var heart_instance = heart_scene.instantiate()
			$HBoxContainer.add_child(heart_instance)

func validate_hp() -> void:
	# Ограничиваем ХП, чтобы оно не стало больше макс. и меньше 0
	current_hp = clampi(current_hp, 0, max_hp)
