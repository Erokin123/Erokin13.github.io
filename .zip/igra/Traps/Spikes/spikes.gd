extends Node2D

@onready var hp_bar = $"."

func _on_area_2d_player_entered(body: Node2D) -> void:
		# 1. Сначала проверяем, что в шипы зашел именно Игрок, а не монетка или враг
	if body.name == "Player":
		# 2. Проверяем, есть ли у скрипта игрока функция 'hit'
		if body.has_method("hit"):
			body.hit() # ← Вот теперь мы вызываем её КОРРЕКТНО у игрока!
		else:
			print("Ошибка: У игрока нет функции с именем hit()")
		
		
