extends CanvasLayer

@export var heart_scene : PackedScene
var max_hp: int = 5 
var current_hp: int = 3
@onready var coins_label: Label = $CoinsLabel
@onready var hearts_container: HBoxContainer = $HBoxContainer

func _ready() -> void:
	GlobalVars.coins_ui = self 
	GlobalVars.current_ui = self
	setup_hp()

func heal() -> void:
	current_hp += 1
	validate_hp()
	setup_hp()

func update_coins_display(amount: int) -> void:
	if coins_label != null:
		coins_label.text = str(amount)
	else:
		print("Ошибка: Не найден узел CoinsLabel!")

func hit() -> void:
	current_hp -= 1
	validate_hp()
	setup_hp()

func setup_hp() -> void:
	clean_current_representation()
	draw_hearts()

func clean_current_representation() -> void:
	# Безопасно очищаем сердечки через переменную hearts_container
	if hearts_container != null:
		for child in hearts_container.get_children():
			child.queue_free()
	else:
		print("Ошибка: Не найден контейнер для сердечек HBoxContainer!")

func draw_hearts() -> void:
	if current_hp > 0 and hearts_container != null:
		for x in current_hp:
			var heart_instance = heart_scene.instantiate()
			hearts_container.add_child(heart_instance)

func validate_hp() -> void:
	current_hp = clampi(current_hp, 0, max_hp)
