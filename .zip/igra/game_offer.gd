extends CanvasLayer



func _on_youdied_pressed() -> void:
	get_tree().change_scene_to_file("res://Menu/main_menu.tscn")


func _on_timer_timeout() -> void:
	_on_youdied_pressed()
