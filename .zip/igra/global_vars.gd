extends Node

var score : int
var hi_score :int
var coins_ui = null

var current_ui = null  
