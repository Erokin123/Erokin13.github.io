extends Node2D

@export var next_scene : String




func _on_door_open_anim_body_entered(body: Node2D) -> void:
	if body.name != "Player":
		return
	$Open.show()
	



func _on_door_open_anim_body_exited(body: Node2D) -> void:
	if body.name != "Player":
		return
func _on_go_to_new_scene_body_entered(body: Node2D) -> void:
	get_tree().change_scene_to_file.call_deferred("res://world2.tscn")
