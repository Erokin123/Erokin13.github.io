extends Area2D

@export var speed: float = 500.0 # Скорость полета монетки к игроку

var target_player: Node2D = null  # Ссылка на игрока, к которому летим
var can_magnet: bool = false     # Флаг задержки: можно ли уже магнититься
var is_picked_up: bool = false   # Флаг, чтобы звук не вызывался много раз

func _ready() -> void:
	# Ждем 1.5 секунды после появления монеты, прежде чем она сможет лететь к игроку
	await get_tree().create_timer(1.5).timeout
	can_magnet = true

func _process(delta: float) -> void:
	# Если задержка прошла, и у нас есть цель (игрок) — плавно летим к нему
	if can_magnet and target_player and not is_picked_up:
		var direction = (target_player.global_position - global_position).normalized()
		global_position += direction * speed * delta
		
		# Проверяем: если монетка подлетела вплотную к центру игрока (ближе 15 пикселей)
		if global_position.distance_to(target_player.global_position) < 15.0:
			collect_and_destroy()

# Эту функцию вызывает ИГРОК, когда монета попадает в его зону сбора
func on_pickup(player: Node2D) -> void:
	# Просто запоминаем игрока. Монетка начнет лететь к нему, как только can_magnet станет true
	target_player = player
	queue_free()

# Финальный сбор монетки (твой старый код, перенесенный сюда)
func collect_and_destroy() -> void:
	is_picked_up = true # Защита от повторного срабатывания
	
	# 1. Делаем монетку невидимой сразу
	visible = false
	
	# 2. Выключаем коллизию
	set_deferred("monitoring", false)
	set_deferred("monitorable", false)
	
	# Тут можно добавить золото в ваш глобальный скрипт, например:
	# Global.gold += 1
	
	# 3. Проверяем звук и проигрываем его
	if $Sound and $Sound.stream:
		$Sound.play()
		await $Sound.finished # Ждем окончания звука
	
	# 4. Вот теперь окончательно удаляем с карты
	queue_free()
