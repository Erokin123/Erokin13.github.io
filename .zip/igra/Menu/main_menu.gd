extends CanvasLayer



func _on_start_pressed() -> void:
	GlobalVars.score = 0 
	if not GlobalVars.hi_score:
		GlobalVars.hi_score = 0   
	get_tree().change_scene_to_file("res://Level/Level.tscn")

func _on_exit_pressed() -> void:
	get_tree().quit()
