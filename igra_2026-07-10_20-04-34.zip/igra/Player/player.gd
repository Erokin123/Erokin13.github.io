extends CharacterBody2D


const SPEED = 300.0
const JUMP_VELOCITY = -400.0
@onready var anim: AnimatedSprite2D = $AnimatedSprite2D

func _ready() -> void:
	GlobalVars
func _physics_process(delta: float) -> void:
	
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Handle jump.
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction := Input.get_axis("ui_left", "ui_right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
		
	update_animation()

	move_and_slide()
func update_animation():
	if velocity.x < 0 :
		anim.flip_h = true
	elif velocity.x > 0 :
		anim.flip_h = false 
		anim.play("Run")
	if velocity.x:
		anim.play("Run")
	else:
		anim.play("Idle")
	if velocity.y <0:
		anim.play("Run")
	elif velocity.y > 0 :
		anim.play("Fall")
func on_death():
	get_tree().change_scene_to_file.call.call_deferred("res://game_offer.tscn")
	self.queue_free()


func _on_pickup_area_area_entered(area: Area2D) -> void:
	if area.has_method("on_pickup"):
		area.on_pickup() 
