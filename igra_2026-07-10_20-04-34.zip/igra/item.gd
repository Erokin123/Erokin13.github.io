extends Area2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func on_pickup() -> void:
	# 1. Делаем монетку невидимой сразу
	visible = false
	
	# 2. Выключаем коллизию, чтобы её нельзя было взять еще раз
	# (Здесь используем set_deferred, чтобы не было ошибки физики, о которой говорили в самом начале)
	set_deferred("monitoring", false)
	set_deferred("monitorable", false)
	
	# 3. Проверяем звук и проигрываем его
	if $Sound and $Sound.stream:
		$Sound.play()
		await $Sound.finished # Ждем окончания звука
	
	# 4. Вот теперь окончательно удаляем с карты
	queue_free()
