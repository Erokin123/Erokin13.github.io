extends CharacterBody2D
class_name Player

signal healthChanged
var max_hp: int = 30
var current_hp: int = max_hp
const SPEED = 300.0
const JUMP_VELOCITY = -400.0
var coins: int = 0
@onready var anim: AnimatedSprite2D = $AnimatedSprite2D


# Локальная переменная ui нам больше вообще не нужна, 
# так как мы общаемся с интерфейсом через GLOBAL.current_ui

func _ready() -> void:
	GlobalVars.player = self
	pass # Функция готова к работе, ошибок тут больше нет

func _physics_process(delta: float) -> void:
	# Гравитация
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Прыжок
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Движение влево/вправо
	var direction := Input.get_axis("ui_left", "ui_right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
		
	update_animation()
	move_and_slide()

func update_animation():
	# Поворот персонажа
	if velocity.x < 0:
		anim.flip_h = true
	elif velocity.x > 0:
		anim.flip_h = false 
	
	# Проверяем, где находится игрок
	if is_on_floor():
		if velocity.x != 0:
			anim.play("Run")
		else:
			anim.play("Idle")
	else:
		# Если игрок в воздухе
		if velocity.y < 0:
			anim.play("Run") # Тут будет анимация прыжка, если добавишь
		elif velocity.y > 0:
			anim.play("Fall")
func on_death():
	get_tree().change_scene_to_file.call_deferred("res://Menu/game_offer.tscn")
	self.queue_free()

func _on_pickup_area_area_entered(area: Area2D) -> void:
	# 1. Если у подобранного объекта есть свой метод "on_pickup", вызываем его.
	# Это нужно, чтобы объект (монетка/клубника) знал, что его подобрали, и удалился через queue_free()
	if area.has_method("on_pickup"):
		area.on_pickup(self)
		
		# Переводим имя объекта в маленький регистр, чтобы избежать ошибок с разным написанием букв
		var item_name = area.name.to_lower()
		
		# 2. Проверяем: это монетка, клубника или объект из группы "coins"?
		if item_name.contains("coin") or item_name.contains("strawberry") or area.is_in_group("coins"):
			coins += 1
			print("Предмет собран! Всего очков/монет: ", coins)
			
			# 3. Отправляем обновленный счет в интерфейс через наш синглтон GlobalVars
			if GlobalVars.coins_ui != null:
				GlobalVars.coins_ui.update_coins_display(coins)
			else:
				print("Внимание: Интерфейс монет еще не зарегистрирован в GlobalVars.coins_ui")
				
func hit() -> void:
	# 1. Отнимаем здоровье у САМОГО игрока
	current_hp -= 10
	print("ХП Игрока: ", current_hp)
	healthChanged.emit()

	# 2. Передаем команду интерфейсу напрямую через Глобальный скрипт
	if GlobalVars.current_ui != null:
		GlobalVars.current_ui.hit() 
	else:
		print("Внимание: Интерфейс еще не зарегистрирован в GLOBAL.current_ui")
		
	# 3. Проверяем смерть игрока
	if current_hp <= 0:
		
		on_death()
func heal() -> void:
	# 1. Проверяем, не заполнено ли уже здоровье до максимума
	if current_hp >= max_hp:
		print("У игрока уже максимальное здоровье!")
		return # Если здоровье полное, прерываем функцию (аптечка не подберётся)
		
	# 2. Прибавляем здоровье САМОМУ игроку
	current_hp += 1
	print("Игрок исцелен! Текущее ХП: ", current_hp)
	
	# 3. Передаем команду интерфейсу обновиться через Глобалку
	if GlobalVars.current_ui != null:
		GlobalVars.current_ui.heal()
	else:
		print("Внимание: Интерфейс еще не зарегистрирован в GLOBAL.current_ui")
