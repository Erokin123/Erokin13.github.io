extends ProgressBar

var player: Player

func _ready() -> void:
	# Немного подождем, чтобы сцена игрока точно успела загрузиться
	await get_tree().process_frame
	
	# Берем игрока из нашего глобального синглтона
	if GlobalVars.player != null:
		player = GlobalVars.player
		# Подключаем сигнал изменения здоровья
		player.healthChanged.connect(update_bar)
		# Сразу обновляем полоску под текущее ХП
		update_bar()
	else:
		print("Внимание: ProgressBar не смог найти игрока в GlobalVars.player")

func update_bar() -> void:
	if player != null:
		# Высчитываем проценты (от 0 до 100)
		value = player.current_hp * 100 / player.max_hp
