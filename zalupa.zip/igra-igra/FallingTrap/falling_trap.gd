extends Area2D

# Настройки ловушки
const FALL_SPEED = 600.0      # Скорость падения
const TIME_BEFORE_FALL = 3.0  # Пауза перед каждым падением (3 секунды)
const TIME_TO_RESPAWN = 1.0   # Пауза внизу перед возвращением назад

# Переменные состояния
var is_falling: bool = false
var has_hit_something: bool = false
var start_position: Vector2

@onready var sprite: Sprite2D = $Sprite2D
@onready var collision_shape: CollisionShape2D = $CollisionShape2D

func _ready() -> void:
	# Запоминаем стартовую позицию на потолке
	start_position = global_position
	# Запускаем бесконечный цикл падений!
	start_trap_lifecycle()

func _physics_process(delta: float) -> void:
	# Если ловушка в режиме падения — двигаем её строго вниз
	if is_falling:
		position.y += FALL_SPEED * delta

# Бесконечный жизненный цикл ловушки
# Бесконечный жизненный цикл ловушки
func start_trap_lifecycle():
	while true: # Этот цикл будет крутиться постоянно
		# ПОДСТРАХОВКА: Если ловушку удалили или сцена перезагружается, выходим из цикла
		if not is_inside_tree():
			return
			
		# 1. Ждем 3 секунды на потолке
		await get_tree().create_timer(TIME_BEFORE_FALL).timeout
		
		# Еще раз проверяем после долгого ожидания таймера
		if not is_inside_tree():
			return
		
		# 2. Включаем падение
		is_falling = true
		has_hit_something = false
		print("Ловушка автоматически пошла вниз!")
		
		# 3. Ждем, пока она куда-нибудь упадет
		while is_falling:
			if not is_inside_tree():
				return
			await get_tree().process_frame # Просто ждем окончания падения
# Когда ловушка во что-то врезается
func _on_body_entered(body: Node2D) -> void:
	# Если ловушка случайно коснулась сама себя — просто игнорируем это
	if body == self:
		return
		
	# ПРОВЕРКА УРОНА:
	if (body.name == "Player" or body.has_method("hit")) and not has_hit_something:
		has_hit_something = true
		print("УРА! Ловушка гарантированно попала в: ", body.name)
		if body.has_method("hit"):
			body.hit()
		respawn_trap()
		
	# Если ловушка врезалась в пол
	elif is_falling:
		print("Ловушка ударилась о землю: ", body.name)
		respawn_trap()

# Функция возврата на потолок
func respawn_trap():
	is_falling = false
	# Прячем ловушку и временно выключаем коллизию
	sprite.visible = false
	collision_shape.set_deferred("disabled", true)
	
	# Ждем 1 секунду внизу перед телепортацией назад
	await get_tree().create_timer(TIME_TO_RESPAWN).timeout
	
	# Телепортируем обратно наверх
	global_position = start_position
	sprite.visible = true
	collision_shape.set_deferred("disabled", false)
