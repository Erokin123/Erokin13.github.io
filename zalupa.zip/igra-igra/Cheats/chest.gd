extends Node2D

@onready var anim: AnimatedSprite2D = $AnimatedSprite2D

# Сцена монетки
@export var coin_scene: PackedScene = preload("res://Gold/Gold.tscn")

var is_opened: bool = false

func _ready() -> void:
	# Принудительно закрываем сундук при запуске игры
	is_opened = false
	anim.stop()
	anim.play("idle")  # ← название твоей анимации закрытого сундука



func open_chest() -> void:
	if is_opened:
		return
		
	is_opened = true
	anim.play("open")      # анимация открытия
	print("Сундук открыт!")
	
	spawn_coin()

func spawn_coin() -> void:
	if coin_scene:
		# Создаем копию монеты
		var coin_instance = coin_scene.instantiate()
		
		# Ставим монету в координаты сундука
		coin_instance.global_position = global_position
		
		# Добавляем на уровень
		get_parent().call_deferred("add_child", coin_instance) # ИСПРАВЛЕНО




func _on_area_body_entered(body: Node2D) -> void:
	if body.name == "Player" and not is_opened:
		open_chest()


func _on_area_body_exited(body: Node2D) -> void:
	pass # Replace with function body.
